#!/var/jb/usr/bin/bash
echo "bilibili@玩科技的李子"
echo "token密钥"
echo "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"
echo " "
echo "__________________________________"
echo "__________________________________"
echo "__________________________________"
echo "开始推送"
git add .
echo "上传状态"
echo "done.....100%"
echo "__________________________________"
echo "____________输入token_____________"
echo "__________________________________"
git status
git commit -m "updata"
git push
echo "推送完成"
echo "successful"