echo 所有权归 bilibili@玩科技的李子 所有，不要随意传播
echo安装前请阅读/var/jb/var/mobile里的必读文件.txt
sudo apt install theos-dependencies
git clone --recursive https://github.com/theos/theos.git $THEOS
curl -LO https://github.com/theos/sdks/archive/master.zip
TMP=$(mktemp -d)
unzip master.zip -d $TMP
mv $TMP/sdks-master/*.sdk $THEOS/sdks
rm -r master.zip $TMP